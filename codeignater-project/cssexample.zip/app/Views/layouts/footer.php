<footer class="footer">
    <div class="container">
        <div class="footer__inner">

            <div class="footer__topBlock">
                <div class="footer__logo">
                    <a href="#"><img src="../images/footer_logo.png" alt="Лого cайта"></a>
                </div>
                <ul class="footer__categories">
                    <li class="footer__categories-item"><a href="#" class="footer__categorieslink">Ноутбуки</a></li>
                    <li class="footer__categories-item"><a href="#" class="footer__categories-link">Планшеты</a></li>
                    <li class="footer__categories-item"><a href="#" class="footer__categories-link">cмартфоны</a></li>
                    <li class="footer__categories-item"><a href="#" class="footer__categories-link">Наушники</a></li>
                    <li class="footer__categories-item"><a href="#" class="footer__categories-link">Телевизоры</a></li>
                    <li class="footer__categories-item"><a href="#" class="footer__categories-link">Акcеccуары</a></li>
                </ul>
            </div>


            <div class="footer__bottomBlock">
                <ul class="footer__nav">
                    <li class="footer__nav-item"><a href="#" class="footer__nav-link">Политика конфиденциальноcти</a></li>
                    <li class="footer__nav-item"><a href="#" class="footer__nav-link">О компании</a></li>
                    <li class="footer__nav-item"><a href="#" class="footer__nav-link">Новоcти</a></li>
                    <li class="footer__nav-item"><a href="#" class="footer__nav-link">Контакты</a></li>
                </ul>
                <p class="footer__copyright">Copyright © 2001-2023 RudzPark. All rights reserved</p>
            </div>
      </div>
    </div>
</footer>

