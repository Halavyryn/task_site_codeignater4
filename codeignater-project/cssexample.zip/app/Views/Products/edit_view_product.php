<!DOCTYPE html>
<html>
<head>
    <title>Редоктирование продукта</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <style>
        .container {
            max-width: 500px;
        }
        .error {
            display: block;
            padding-top: 5px;
            font-size: 14px;
            color: red;
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <?php if(session()->get('email') !== null): ?>
        <h2>Редоктирование продукта</h2>
        <form method="post" id="update_product" name="update_product"
              action="<?= base_url('products/update') ?>"
              enctype="multipart/form-data">

             <input type="hidden" name="id_product" id="id_product" value="<?php echo $product_obj['id_product']; ?>">


            <div class="form-group">
                <label>Название продукта</label>
                <input type="text" name="name_product" class="form-control" value="<?= old( 'name_product', $product_obj['name_product'])?>">
            </div>

            <div class="form-group">
                <label>Категория продукта</label>
                <?php if($categories): ?>
                    <select class="form-control" name="category_id" id="category_id">
                        <?php foreach($categories as $category): ?>
                            <option value="<?php echo $category['id']; ?>"><?php echo $category['name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label>Наличие продукта</label>
                <select class="form-control" name="check_mark_product" id="check_mark_product">
                    <option value="в наличии" <?= ($product_obj['check_mark_product'] === 'в наличии"') ? 'selected': '' ?> >в наличии</option>
                    <option value="нет в наличии" <?= ($product_obj['check_mark_product']  === 'нет в наличии') ? 'selected': '' ?> >нет в наличии</option>
                </select>
            </div>

            <div class="form-group">
                <label>Цена продукта</label>
                <input type="text" name="price_product" class="form-control" value="<?php echo $product_obj['price_product']; ?>">
            </div>

            <div class="form-group">
                <label>Рейтинг продукта</label>
                <input type="text" name="rating_product" class="form-control" value="<?php echo $product_obj['rating_product']; ?>">
            </div>

           <!-- <div class="form-group">
                <label>Изображение товара</label>
                <input type="file" name="file" accept="image/png, image/jpeg" class="form-control">
            </div>-->


            <div class="form-group">
                <button type="submit" class="btn btn-danger btn-block">Сохранить изменения</button>
            </div>
        </form>
        <div class="list-group col-6">
            <a href="<?php echo site_url('products/product-list') ?>" class="btn btn-secondary mb-2">К списку продуктов</a>
            <a href="<?php echo site_url('/') ?>" class="btn btn-secondary mb-2">На главную</a>
            <a href="<?php echo site_url('admin') ?>" class="btn btn-secondary mb-2">Меню редактора</a>
        </div>
    <?php else: ?>
        <?php echo '<h1>У вас нет прав для этой страницы</h1>' ?>
    <?php endif; ?>

</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/additional-methods.min.js"></script>
<script>
    if ($("#update_product").length > 0) {
        $("#update_product").validate({
            rules: {
                name_product: {
                    required: true,
                },
                check_mark_product: {
                    required: true,
                },
                price_product: {
                    required: true,
                },
                rating_product: {
                    required: true,
                },
                img_product: {
                    required: true,
                },
            },
            messages: {
                name_product: {
                    required: "Введите правильное имя",
                },
                check_mark_product: {
                    required: "Введите наличие продукта",
                },
                price_product: {
                    required: "Введите цену продукта",
                },
                rating_product: {
                    required: "Введите рейтинг продукта",
                },
                img_product: {
                    required: "Введите картинку продукта",
                },
            },
        })
    }
</script>
</body>
</html>
