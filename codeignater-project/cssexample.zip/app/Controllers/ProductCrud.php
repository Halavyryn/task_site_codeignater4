<?php
namespace App\Controllers;
use App\Models\ProductModel;
use App\Models\CategoryModel;
use CodeIgniter\Controller;
use CodeIgniter\API\ResponseTrait;

class ProductCrud extends Controller
{
    use ResponseTrait;

    // show categories list
    public function index(){
        $productModel = new ProductModel();
        $categoryModel = new CategoryModel();

        $data['products'] = $productModel->orderBy('id_product', 'ASC')->findAll();
        $data['categories'] =  $categoryModel -> orderBy('id', 'ASC')->findAll();
        return view('products/product_view', $data);
    }

    // add category form
    public function create(){
        $categoryModel = new CategoryModel();
        $data['categories'] =  $categoryModel -> orderBy('id', 'ASC')->findAll();
        return view('products/add_product', $data);
    }

    // insert data
    public function store() {
        $productModel = new ProductModel();

        //IMG START
        helper(['form', 'url']);

        $input = $this->validate([
            'file' => [
                'uploaded[file]',
                'mime_in[file,image/jpg,image/jpeg,image/png]',
                'max_size[file,1024]',
            ]
        ]);
        if (!$input) {
            print_r('Choose a valid file');
        } else {
            $file = $this->request->getFile('file');
            $file->move(FCPATH. 'uploads');
            //IMG END

            $data = [
                'name_product' => $this->request->getPost('name_product'),
                'category_id' => $this->request->getPost('category_id'),
                'check_mark_product' => $this->request->getPost('check_mark_product'),
                'price_product' => $this->request->getPost('price_product'),
                'rating_product' => $this->request->getPost('rating_product'),
                'file' => $file->getName(),
            ];

            $save = $productModel->insert($data);
            if($save){
                print_r('Data insert');
            }else{
                print_r('Data not insert');
            }
            return $this->response->redirect(site_url('products/product-list'));
        }
    }

    // show single category
    public function singleUser($id_product = null){
        $productModel = new ProductModel();
        $categoryModel = new CategoryModel();
        $data['product_obj'] = $productModel -> where('id_product', $id_product)->first();
        $data['categories'] =  $categoryModel -> orderBy('id', 'ASC')->findAll();
        return view('products/edit_view_product', $data);
    }

    // delete category
    public function delete($id_product = null){
        $productModel = new ProductModel();
        $productModel->where('id_product', $id_product)->delete($id_product);
        return $this->response->redirect(site_url('products/product-list'));
    }

    // update product data
    public function update(){

        $productModel = new ProductModel();
        $id_product = $this->request->getPost('id_product');

        //IMG START
        helper(['form', 'url']);

      /*  $input = $this->validate([
            'file' => [
                'uploaded[file]',
                'mime_in[file,image/jpg,image/jpeg,image/png]',
                'max_size[file,1024]',
            ]
        ]);*/

            /*$file = $this->request->getFile('file');
            $file->move(FCPATH . 'uploads');*/
            //IMG END

            $data = [
                'name_product' => $this->request->getPost('name_product'),
                'category_id' => $this->request->getPost('category_id'),
                'check_mark_product' => $this->request->getPost('check_mark_product'),
                'price_product' => $this->request->getPost('price_product'),
                'rating_product' => $this->request->getPost('rating_product'),
                /*'file' => $file->getName(),*/
            ];

            $save = $productModel->update($id_product, $data);
            if ($save) {
                print_r('Data update');
            } else {
                print_r('Data not update');
            }

            return $this->response->redirect(site_url('products/product-list'));
    }

    function upload() {
        helper(['form', 'url']);

        $database = \Config\Database::connect();
        $db = $database->table('images');

        $input = $this->validate([
            'file' => [
                'uploaded[file]',
                'mime_in[file,image/jpg,image/jpeg,image/png]',
                'max_size[file,1024]',
            ]
        ]);

        if (!$input) {
            print_r('Choose a valid file');
        } else {
            $img = $this->request->getFile('file');
            $img->move(WRITEPATH . 'uploads');

            $data = [
                'name_images' =>  $img->getName(),
                'type_images'  => $img->getClientMimeType(),
            ];

            $save = $db->insert($data);
            print_r('File has successfully uploaded');
        }
    }

    public function getProducts()
    {
        $productModel = new ProductModel();
        $products = $productModel->where('category_id', $this->request->getPost('category_id'))->findAll();
        return $this->respond($products);
    }

}
